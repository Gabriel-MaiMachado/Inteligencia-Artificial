import random



def funcao_ativacao(soma):

    if soma >= 0:
        return 1
    return -1


def treinar(amostras, saidas, taxa_aprendizado=0.1, geracoes=1000):
    n_amostras = len(amostras)
    n_atributos = len(amostras[0])

    for amostra in amostras:
        amostra.insert(0, 1)

    pesos = [random.random() for _ in range(n_atributos + 1)]

    geracao = 0
    while True:
        aprendeu = True

        for i in range(n_amostras):
            soma = 0
            for j in range(n_atributos + 1):
                soma += pesos[j] * amostras[i][j]

            saida_gerada = funcao_ativacao(soma)

            if saida_gerada != saidas[i]:
                erro = saidas[i] - saida_gerada
                for j in range(n_atributos + 1):
                    pesos[j] = pesos[j] + taxa_aprendizado * erro * amostras[i][j]
                aprendeu = False

        geracao += 1
        if aprendeu or geracao > geracoes:
            print('Quantidade de gerações para aprender: %d\n' % geracao)
            break

    return pesos


def testar(pesos, amostra):
    amostra.insert(0, 1)  

    soma = 0
    for i in range(len(amostra)):
        soma += pesos[i] * amostra[i]

    saida_gerada = funcao_ativacao(soma)

    if saida_gerada == 1:
        print('Classe: %d. Empréstimo Aprovado! ✅' % saida_gerada)
    else:
        print('Classe: %d. Empréstimo Recusado! ❌' % saida_gerada)



amostras = [
    [0.10, 0.20],
    [0.25, 0.30],
    [0.40, 0.15],
    [0.20, 0.50], 
    [0.70, 0.65],  
    [0.90, 0.80],  
    [0.60, 0.90],  
    [0.85, 0.55]
    ]  

saidas = [-1, -1, -1, -1, 1, 1, 1, 1]

pesos_finais = treinar(amostras, saidas)
print('Pesos finais:', pesos_finais)
print()

while True:
    historico = float(input('Histórico de crédito (0 a 1): '))
    renda = float(input('Renda mensal normalizada (0 a 1): '))
    print('Ponto: ', historico, ' , ', renda)
    testar(pesos_finais, [historico, renda])
    print()
