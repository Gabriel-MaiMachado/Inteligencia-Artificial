import random

def funcao_ativacao(soma):
    if soma >= 0:
        return 1
    return -1


def treinar(amostras, saidas, taxa_aprendizado=0.1, geracoes=1000):
    n_amostras = len(amostras)
    n_atributos = len(amostras[0])

    for amostra in amostras:
        amostra.insert(0, 1)

    pesos = [random.random() for _ in range(n_atributos + 1)]

    geracao = 0
    while True:
        aprendeu = True

        for i in range(n_amostras):
            soma = 0
            for j in range(n_atributos + 1):
                soma += pesos[j] * amostras[i][j]

            saida_gerada = funcao_ativacao(soma)

            if saida_gerada != saidas[i]:
                erro = saidas[i] - saida_gerada
                for j in range(n_atributos + 1):
                    pesos[j] = pesos[j] + taxa_aprendizado * erro * amostras[i][j]
                aprendeu = False

        geracao += 1
        if aprendeu or geracao > geracoes:
            print('Quantidade de gerações para aprender: %d\n' % geracao)
            break

    return pesos


def testar(pesos, amostra):
    amostra.insert(0, 1)

    soma = 0
    for i in range(len(amostra)):
        soma += pesos[i] * amostra[i]

    saida_gerada = funcao_ativacao(soma)

    if saida_gerada == 1:
        print('Classe: %d. Vai Chover! 🌧️' % saida_gerada)
    else:
        print('Classe: %d. Dia de Sol! ☀️' % saida_gerada)

amostras = [
    [0.20, 0.90],  
    [0.35, 0.85],  
    [0.15, 0.75],  
    [0.40, 0.80],  
    [0.55, 0.45],  
    [0.85, 0.30],  
    [0.90, 0.20],  
    [0.75, 0.35]   
]

saidas = [-1, -1, -1, -1, 1, 1, 1, 1]

pesos_finais = treinar(amostras, saidas)
print('Pesos finais:', pesos_finais)
print()

while True:
    umidade = float(input('Umidade normalizada (0 a 1): '))
    pressao = float(input('Pressão normalizada (0 a 1): '))
    print('Ponto: ', umidade, ' , ', pressao)
    testar(pesos_finais, [umidade, pressao])
    print()
