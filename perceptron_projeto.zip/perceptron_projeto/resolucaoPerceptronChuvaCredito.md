# Resolvendo o desafio do Perceptron (Chuva e Crédito)

Esse arquivo é só pra explicar rapidinho como resolvi o desafio que tava no `desafioPerceptronChuvaCredito.md`. Basicamente peguei o Perceptron original (dos times) e adaptei pra dois casos novos: prever chuva e decidir se aprova um empréstimo.

## Como funciona (rapidão)

O Perceptron é aquele classificador simples que aprende uma "reta" que separa duas classes. Ele vai ajustando os pesos toda vez que erra, até acertar tudo ou bater no limite de gerações. O código é basicamente o mesmo nos dois arquivos, só muda:

- os dados de entrada
- as saídas esperadas
- as mensagens no final (chuva/sol ou aprovado/recusado)

## Chuva ☔ (`perceptron_chuva.py`)

Entrada: umidade e pressão (normalizadas de 0 a 1).

- Pouca umidade + pressão alta = Sol (-1)
- Muita umidade + pressão baixa = Chuva (1)

Faz sentido: pressão alta segura o tempo firme, e sem umidade não forma nuvem. Os dados ficam bem separadinhos num canto e no outro do gráfico, então o Perceptron aprende rápido, sem drama.

## Crédito 💳 (`perceptron_credito.py`)

Entrada: histórico de crédito e renda mensal (também de 0 a 1).

- Histórico ruim + renda baixa = Recusado (-1)
- Histórico bom + renda boa = Aprovado (1)

Mesma lógica de antes, só que aqui quanto mais alto os dois valores, melhor pro cliente. De novo, os grupos ficam bem separados, então dá pra traçar uma linha reta dividindo quem é aprovado de quem é recusado.

## Resumindo os dois

| | Chuva | Crédito |
|---|---|---|
| Entrada 1 | Umidade | Histórico de crédito |
| Entrada 2 | Pressão | Renda mensal |
| -1 | Sol | Recusado |
| 1 | Chuva | Aprovado |

Nos dois casos os dados são "linearmente separáveis", ou seja, dá pra separar as classes com uma reta só. Por isso o Perceptron dá conta do recado sem precisar de nada mais complexo.

## Rodando

```bash
python3 perceptron_chuva.py
python3 perceptron_credito.py
```

Treina sozinho ao rodar e depois fica te pedindo os valores pra testar.

## Conclusão

No fim das contas é o mesmo código pros dois problemas, só troquei os dados e as mensagens. Mostra bem que o Perceptron não "entende" chuva nem crédito — ele só separa números que representam esses problemas.
